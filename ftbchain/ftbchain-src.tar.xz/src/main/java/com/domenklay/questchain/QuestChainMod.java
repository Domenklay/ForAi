package com.domenklay.questchain;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.loading.FMLEnvironment;

/** Optional client-only extension: no server installation and no quest file edits. */
@Mod(QuestChainMod.MOD_ID)
public final class QuestChainMod {
    public static final String MOD_ID = "ftbchaintracker";

    public QuestChainMod(IEventBus modBus) {
        if (FMLEnvironment.dist == Dist.CLIENT) {
            ClientTracker.init(modBus);
        }
    }
}
