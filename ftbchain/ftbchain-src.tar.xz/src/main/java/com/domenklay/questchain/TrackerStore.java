package com.domenklay.questchain;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.neoforged.fml.loading.FMLPaths;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/** Persists selected roots by single-player world name / multiplayer address. */
final class TrackerStore {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type TYPE = new TypeToken<Map<String, String>>() {}.getType();
    private static final Path PATH = FMLPaths.CONFIGDIR.get().resolve("ftbchaintracker-roots.json");
    private final Map<String, String> roots = new HashMap<>();

    TrackerStore() {
        try {
            if (Files.isRegularFile(PATH)) {
                Map<String, String> loaded = GSON.fromJson(Files.readString(PATH, StandardCharsets.UTF_8), TYPE);
                if (loaded != null) roots.putAll(loaded);
            }
        } catch (RuntimeException | IOException e) {
            System.err.println("[FTB Chain Tracker] Could not read saved roots: " + e);
        }
    }

    Long get(String key) {
        String hex = roots.get(key);
        if (hex == null) return null;
        try { return Long.parseUnsignedLong(hex, 16); }
        catch (NumberFormatException ignored) { return null; }
    }

    void put(String key, Long questId) {
        if (questId == null) roots.remove(key);
        else roots.put(key, Long.toUnsignedString(questId, 16));
        try {
            Files.createDirectories(PATH.getParent());
            Files.writeString(PATH, GSON.toJson(roots, TYPE), StandardCharsets.UTF_8);
        } catch (IOException e) {
            System.err.println("[FTB Chain Tracker] Could not save roots: " + e);
        }
    }
}
