package com.domenklay.questchain.mixin;

import com.domenklay.questchain.PinnedOverlayRenderer;
import dev.ftb.mods.ftbquests.client.PinnedQuestsTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Patch the original FTB pinned display instead of adding a separate HUD on top of it. */
@Mixin(value = PinnedQuestsTracker.class, remap = false)
public abstract class PinnedTrackerMixin {
    @Inject(method = "render", at = @At("HEAD"), cancellable = true, remap = false)
    private void ftbchaintracker$renderInNativeSlot(Minecraft minecraft, GuiGraphics graphics, CallbackInfo ci) {
        PinnedOverlayRenderer.render(minecraft, graphics);
        ci.cancel();
    }
}
