package com.domenklay.questchain;

import dev.ftb.mods.ftblibrary.icon.Icon;
import dev.ftb.mods.ftblibrary.icon.ItemIcon;
import dev.ftb.mods.ftbquests.client.AutoPinTarget;
import dev.ftb.mods.ftbquests.client.ClientQuestFile;
import dev.ftb.mods.ftbquests.client.FTBQuestsClientConfig;
import dev.ftb.mods.ftbquests.client.PinnedTrackerVisibility;
import dev.ftb.mods.ftbquests.client.gui.quests.QuestScreen;
import dev.ftb.mods.ftbquests.quest.Quest;
import dev.ftb.mods.ftbquests.quest.TeamData;
import dev.ftb.mods.ftbquests.quest.task.ItemTask;
import dev.ftb.mods.ftbquests.quest.task.Task;
import it.unimi.dsi.fastutil.longs.LongSet;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** The original FTB Quests pinned HUD slot, adapted for nearby actionable item objectives. */
public final class PinnedOverlayRenderer {
    private static final int WIDTH = 205;
    private static final int MAX_OBJECTIVE_ROWS = 20;
    private static final int TOP_OFFSET_PX = 32;
    private static final int HEADER_HEIGHT = 16;
    private static final int OBJECTIVE_HEIGHT = 13;
    private static final int FOOTER_HEIGHT = 13;
    private static final int TEXT_COLOR = 0xFFE7E7E7;
    private static final int PROGRESS_COLOR = 0xFF6FCFAF;
    private static final int DIM_COLOR = 0xFFB4B4B4;

    // A large FTB book can contain thousands of nodes. Collect the ready objectives
    // periodically, not at render frequency; refresh data when switching tabs.
    private static ClientQuestFile cachedFile;
    private static long lastScanTick = Long.MIN_VALUE;
    private static boolean cachedChainMode;
    private static long cachedChapterId = Long.MIN_VALUE;
    private static List<Row> cachedRows = List.of();

    private PinnedOverlayRenderer() {}

    public static void render(Minecraft mc, GuiGraphics gui) {
        if (mc.player == null || mc.level == null || mc.options.hideGui || !ClientQuestFile.exists()) return;
        if (!ClientTracker.isHudVisible() || FTBQuestsClientConfig.PINNED_VISIBILITY.get() == PinnedTrackerVisibility.HIDDEN) return;

        ClientQuestFile file = ClientQuestFile.getInstance();
        TeamData data = file.selfTeamData;
        if (data == null) return;
        boolean chain = ClientTracker.isChainTracking();
        long chapterId = chapterToShow(file, data, chain);
        long tick = mc.level.getGameTime();
        if (file != cachedFile || chain != cachedChainMode || chapterId != cachedChapterId
                || tick < lastScanTick || tick - lastScanTick >= 10L) {
            cachedRows = collectRows(file, data, mc, chain, chapterId);
            cachedFile = file;
            cachedChainMode = chain;
            cachedChapterId = chapterId;
            lastScanTick = tick;
        }
        if (cachedRows.isEmpty() && !chain) return;

        Font font = mc.font;
        float scale = FTBQuestsClientConfig.PINNED_QUESTS_SCALE.get().floatValue();
        int width = Math.min(WIDTH, Math.max(100, gui.guiWidth() - 12));

        // Include a small top inset for the minimap's coordinate / biome display.
        int availablePixelHeight = Math.max(38, gui.guiHeight() - TOP_OFFSET_PX - 12);
        int availableUnscaledHeight = (int) (availablePixelHeight / scale);
        int maxByHeight = Math.max(0, (availableUnscaledHeight - HEADER_HEIGHT - 5 - FOOTER_HEIGHT) / OBJECTIVE_HEIGHT);
        int itemCap = QuestPriority.visibleRows(cachedRows.size(), Math.min(MAX_OBJECTIVE_ROWS, maxByHeight));
        int hiddenCount = Math.max(0, cachedRows.size() - itemCap);
        boolean showFooter = hiddenCount > 0 || (chain && cachedRows.isEmpty());
        int height = HEADER_HEIGHT + 5 + itemCap * OBJECTIVE_HEIGHT + (showFooter ? FOOTER_HEIGHT : 0);

        int insetX = FTBQuestsClientConfig.PINNED_QUESTS_INSET_X.get();
        int insetY = FTBQuestsClientConfig.PINNED_QUESTS_INSET_Y.get();
        var pos = FTBQuestsClientConfig.PINNED_QUESTS_POS.get().getPanelPos(
                gui.guiWidth(), gui.guiHeight(), (int) Math.ceil(width * scale),
                (int) Math.ceil(height * scale), insetX, insetY);
        int shiftedY = Math.max(2, Math.min(pos.y() + TOP_OFFSET_PX,
                gui.guiHeight() - (int) Math.ceil(height * scale) - 2));

        gui.pose().pushPose();
        gui.pose().translate(pos.x(), shiftedY, 0);
        gui.pose().scale(scale, scale, 1);
        gui.fill(0, 0, width, height, 0xA9000000);
        gui.fill(1, 1, width - 1, HEADER_HEIGHT, 0x535A5A5A);
        gui.fill(0, HEADER_HEIGHT, width, HEADER_HEIGHT + 1, 0xDD000000);
        String title = Component.translatable("hud.ftbchaintracker.header").getString();
        if (chain) title += " · " + Component.translatable("hud.ftbchaintracker.chain").getString();
        title = fit(font, title, width - 12);
        gui.drawString(font, title, (width - font.width(title)) / 2, 4, 0xFFFFFF7A, false);

        int y = HEADER_HEIGHT + 3;
        for (int i = 0; i < itemCap; i++) {
            Row row = cachedRows.get(i);
            Icon icon = row.icon;
            int textX = 9;
            if (icon != null && !icon.isEmpty()) {
                icon.draw(gui, 5, y, 12, 12);
                textX = 20;
            }
            int progressWidth = font.width(row.progress);
            int nameWidth = width - textX - progressWidth - 12;
            if (nameWidth > 6) {
                gui.drawString(font, fit(font, row.name, nameWidth), textX, y + 2, TEXT_COLOR, false);
            }
            gui.drawString(font, row.progress, width - 5 - progressWidth, y + 2, PROGRESS_COLOR, false);
            y += OBJECTIVE_HEIGHT;
        }
        if (showFooter) {
            String footer = hiddenCount > 0 ? "+" + hiddenCount + " …"
                    : Component.translatable("hud.ftbchaintracker.waiting").getString();
            gui.drawString(font, fit(font, footer, width - 18), 10, y + 2, DIM_COLOR, false);
        }
        gui.pose().popPose();
    }

    private static String fit(Font font, String text, int available) {
        if (available <= 0) return "";
        if (font.width(text) <= available) return text;
        return font.plainSubstrByWidth(text, Math.max(0, available - font.width("…"))) + "…";
    }

    /**
     * Keep one chapter/tab in view at a time. Use the last selected FTB chapter if
     * it has unfinished actionable quests in this chain; otherwise fall back to
     * the chapter containing the first actionable quest (usually the chosen root).
     */
    private static long chapterToShow(ClientQuestFile file, TeamData data, boolean chain) {
        if (!chain) return file.getQuestScreen().flatMap(QuestScreen::getSelectedChapter)
                .map(c -> c.getId()).orElse(Long.MIN_VALUE);

        List<Quest> pending = ClientTracker.chainQueue();
        long selected = file.getQuestScreen().flatMap(QuestScreen::getSelectedChapter)
                .map(c -> c.getId()).orElse(Long.MIN_VALUE);
        if (selected != Long.MIN_VALUE && pending.stream().anyMatch(q ->
                q.getChapter().getId() == selected && isReady(q, data))) return selected;

        for (Quest q : pending) {
            if (isReady(q, data)) return q.getChapter().getId();
        }
        return pending.isEmpty() ? selected : pending.getFirst().getChapter().getId();
    }

    private static boolean isReady(Quest q, TeamData data) {
        return !data.isCompleted(q) && q.isVisible(data) && data.canStartTasks(q, true);
    }

    private static List<Row> collectRows(ClientQuestFile file, TeamData data, Minecraft mc, boolean chain, long chapterId) {
        List<Quest> candidates = findQuests(file, data, mc, chain, chapterId);
        // Calculate completion at the quest level before splitting into item rows.
        // If coal is finished but iron is missing in the SAME quest, missing iron
        // rises above not-yet-started quests even though its task progress is 0.
        List<QuestPriority.Entry<Quest>> groups = new ArrayList<>();
        for (int i = 0; i < candidates.size(); i++) {
            Quest quest = candidates.get(i);
            int finished = 0;
            for (Task t : quest.getTasks()) if (data.isCompleted(t)) finished++;
            groups.add(new QuestPriority.Entry<>(quest, finished,
                    data.getRelativeProgress(quest), i));
        }
        List<Row> result = new ArrayList<>();
        for (var group : QuestPriority.ordered(groups)) {
            Quest q = group.quest();
            List<Task> unfulfilled = q.getTasks().stream().filter(t -> !data.isCompleted(t))
                    .sorted(Comparator.comparingDouble((Task t) -> taskCompletionRatio(data, t)).reversed())
                    .toList();
            if (unfulfilled.isEmpty()) {
                if (!q.getTasks().isEmpty()) continue; // all tasks done; wait for actual quest completion
                result.add(new Row(q.getTitle().getString(), data.getRelativeProgress(q) + "%", q.getIcon()));
                continue;
            }
            for (Task task : unfulfilled) {
                String label = q.getTasks().size() == 1 ? q.getTitle().getString() : task.getTitle().getString();
                String progress = task.formatProgress(data, data.getProgress(task)) + "/" + task.formatMaxProgress();
                result.add(new Row(label, progress, resolveIcon(task, q)));
            }
        }
        return List.copyOf(result);
    }

    private static double taskCompletionRatio(TeamData data, Task task) {
        long max = Math.max(1, task.getMaxProgress());
        return Math.min(1.0, (double) data.getProgress(task) / max);
    }

    private static Icon resolveIcon(Task task, Quest quest) {
        Icon icon = task.getIcon();
        if (icon != null && !icon.isEmpty()) return icon;
        if (task instanceof ItemTask item && !item.getItemStack().isEmpty()) {
            icon = ItemIcon.getItemIcon(item.getItemStack());
            if (icon != null && !icon.isEmpty()) return icon;
        }
        return quest.getIcon();
    }

    private static List<Quest> findQuests(ClientQuestFile file, TeamData data, Minecraft mc,
                                          boolean chain, long chapterId) {
        if (chain) {
            List<Quest> result = new ArrayList<>();
            for (Quest q : ClientTracker.chainQueue()) {
                if (q.getChapter().getId() == chapterId && isReady(q, data)) result.add(q);
            }
            return result;
        }

        List<Quest> result = new ArrayList<>();
        LongSet pinned = data.getPinnedQuestIds(mc.player);
        if (pinned == null || pinned.isEmpty()) return result;
        if (pinned.contains(TeamData.AUTO_PIN_ID)) {
            boolean wholeBook = FTBQuestsClientConfig.AUTO_PIN_FOLLOWS.get() == AutoPinTarget.QUEST_BOOK;
            file.forAllQuests(quest -> {
                if (isReady(quest, data) && (wholeBook || file.isChapterSelected(quest.getChapter()))) {
                    result.add(quest);
                }
            });
        } else {
            for (long id : pinned) {
                Quest q = file.getQuest(id);
                if (q != null && isReady(q, data) && (chapterId == Long.MIN_VALUE || q.getChapter().getId() == chapterId)) {
                    result.add(q);
                }
            }
        }
        result.sort(Comparator.comparingLong((Quest q) -> q.getChapter().getId())
                .thenComparingDouble(Quest::getY).thenComparingDouble(Quest::getX)
                .thenComparingLong(Quest::getId));
        return result;
    }

    private record Row(String name, String progress, Icon icon) {}
}
