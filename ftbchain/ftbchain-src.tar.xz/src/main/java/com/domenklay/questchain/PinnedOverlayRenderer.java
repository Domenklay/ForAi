package com.domenklay.questchain;

import dev.ftb.mods.ftblibrary.icon.Icon;
import dev.ftb.mods.ftbquests.client.AutoPinTarget;
import dev.ftb.mods.ftbquests.client.ClientQuestFile;
import dev.ftb.mods.ftbquests.client.FTBQuestsClientConfig;
import dev.ftb.mods.ftbquests.client.PinnedTrackerVisibility;
import dev.ftb.mods.ftbquests.quest.Quest;
import dev.ftb.mods.ftbquests.quest.TeamData;
import dev.ftb.mods.ftbquests.quest.task.Task;
import it.unimi.dsi.fastutil.longs.LongSet;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Compact replacement drawn in FTB Quests' actual pinned-HUD slot. */
public final class PinnedOverlayRenderer {
    private static final int WIDTH = 205;
    private static final int MAX_QUESTS = 10;
    private static final int MAX_TASK_ROWS = 12;
    private static final int MAX_TASKS_PER_QUEST = 3;
    private static final int HEADER_HEIGHT = 16;
    private static final int QUEST_ROW_HEIGHT = 14;
    private static final int TASK_ROW_HEIGHT = 13;
    private static final int TEXT_COLOR = 0xFFE7E7E7;
    private static final int PROGRESS_COLOR = 0xFF6FCFAF;
    private static final int DIM_COLOR = 0xFFB4B4B4;
    private static final int LOCKED_COLOR = 0xFF8F8F8F;

    // Keep graph traversal and server-sync processing out of per-frame rendering.
    private static ClientQuestFile cachedFile;
    private static long lastScanTick = Long.MIN_VALUE;
    private static boolean cachedChainMode;
    private static List<Quest> cachedQuests = List.of();

    private PinnedOverlayRenderer() {}

    public static void render(Minecraft mc, GuiGraphics gui) {
        if (mc.player == null || mc.level == null || mc.options.hideGui || !ClientQuestFile.exists()) return;
        if (!ClientTracker.isHudVisible() || FTBQuestsClientConfig.PINNED_VISIBILITY.get() == PinnedTrackerVisibility.HIDDEN) return;

        ClientQuestFile file = ClientQuestFile.getInstance();
        TeamData data = file.selfTeamData;
        if (data == null) return;

        boolean chainMode = ClientTracker.isChainTracking();
        long tick = mc.level.getGameTime();
        if (file != cachedFile || chainMode != cachedChainMode || tick < lastScanTick || tick - lastScanTick >= 10L) {
            cachedQuests = getQuests(file, data, mc);
            cachedFile = file;
            cachedChainMode = chainMode;
            lastScanTick = tick;
        }
        List<Quest> quests = cachedQuests;
        if (quests.isEmpty() && !chainMode) return;

        double scaleSetting = FTBQuestsClientConfig.PINNED_QUESTS_SCALE.get();
        float scale = (float) scaleSetting;
        int width = Math.min(WIDTH, Math.max(100, gui.guiWidth() - 12));
        // Limit the panel to the available screen height; never introduce scrolling into gameplay.
        int maxHeight = Math.max(HEADER_HEIGHT + 19, (int) ((gui.guiHeight() - 12) / scaleSetting));
        List<Row> rows = new ArrayList<>();
        int height = HEADER_HEIGHT + 5;
        int shownQuests = 0;
        int shownTasks = 0;
        boolean showTasks = chainMode || FTBQuestsClientConfig.PINNED_VISIBILITY.get() == PinnedTrackerVisibility.ALL;

        for (Quest quest : quests) {
            if (shownQuests >= MAX_QUESTS) break;
            boolean locked = chainMode && !data.canStartTasks(quest, false);
            int gap = shownQuests > 0 ? 1 : 0;
            if (height + gap + QUEST_ROW_HEIGHT > maxHeight) break;
            if (gap > 0) { rows.add(Row.spacing(gap)); height += gap; }

            // Draw the exact icon FTB Quests draws in the quest book.  A quest with a
            // single item task may not have a separate task row at all (QUESTS_ONLY).
            // ItemStack-only rendering misses custom/lazy/animated quest icons.
            Icon questIcon = quest.getIcon();
            List<Task> incomplete = quest.getTasks().stream().filter(t -> !data.isCompleted(t)).toList();
            String value = data.getRelativeProgress(quest) + "%";
            if (incomplete.size() == 1 && quest.getTasks().size() == 1) {
                Task onlyTask = incomplete.getFirst();
                value = onlyTask.formatProgress(data, data.getProgress(onlyTask)) + "/" + onlyTask.formatMaxProgress();
                if (questIcon == null || questIcon.isEmpty()) questIcon = onlyTask.getIcon();
            }
            rows.add(Row.quest(quest.getTitle().getString(), value, questIcon, locked));
            height += QUEST_ROW_HEIGHT;
            shownQuests++;

            // A quest with one objective already shows its icon and count in the
            // title row; avoid doubling the row as the old version did.
            if (!showTasks || quest.getTasks().size() <= 1 || incomplete.isEmpty()) continue;
            if (chainMode && quest.hideDetailsUntilStartable() && locked) continue;
            int perQuest = 0;
            for (Task task : incomplete) {
                if (shownTasks >= MAX_TASK_ROWS || perQuest >= MAX_TASKS_PER_QUEST) break;
                if (height + TASK_ROW_HEIGHT > maxHeight) break;
                String taskValue = task.formatProgress(data, data.getProgress(task)) + "/" + task.formatMaxProgress();
                rows.add(Row.task(task.getMutableTitle().getString(), taskValue, task.getIcon(), locked));
                perQuest++;
                shownTasks++;
                height += TASK_ROW_HEIGHT;
            }
            int hidden = incomplete.size() - perQuest;
            if (hidden > 0 && height + 12 <= maxHeight) {
                rows.add(Row.more("+" + hidden + " …"));
                height += 12;
            }
        }
        if (chainMode && quests.isEmpty() && height + 12 <= maxHeight) {
            rows.add(Row.more(Component.translatable("hud.ftbchaintracker.waiting").getString()));
            height += 12;
        } else if (quests.size() > shownQuests && height + 12 <= maxHeight) {
            rows.add(Row.more("+" + (quests.size() - shownQuests) + " …"));
            height += 12;
        }

        int insetX = FTBQuestsClientConfig.PINNED_QUESTS_INSET_X.get();
        int insetY = FTBQuestsClientConfig.PINNED_QUESTS_INSET_Y.get();
        var pos = FTBQuestsClientConfig.PINNED_QUESTS_POS.get().getPanelPos(
                gui.guiWidth(), gui.guiHeight(),
                (int) Math.ceil(width * scaleSetting), (int) Math.ceil(height * scaleSetting), insetX, insetY);
        Font font = mc.font;

        gui.pose().pushPose();
        gui.pose().translate(pos.x(), pos.y(), 0);
        gui.pose().scale(scale, scale, 1);
        gui.fill(0, 0, width, height, 0xA9000000);
        gui.fill(1, 1, width - 1, HEADER_HEIGHT, 0x535A5A5A);
        gui.fill(0, HEADER_HEIGHT, width, HEADER_HEIGHT + 1, 0xDD000000);
        String title = Component.translatable("ftbquests.pinned").getString();
        if (chainMode) title += " · " + Component.translatable("hud.ftbchaintracker.chain").getString();
        title = fit(font, title, width - 12);
        gui.drawString(font, title, (width - font.width(title)) / 2, 4, 0xFFFFFF7A, false);

        int y = HEADER_HEIGHT + 3;
        for (Row row : rows) {
            if (row.type == RowType.SPACING) { y += row.height; continue; }
            if (row.type == RowType.MORE) {
                gui.drawString(font, fit(font, row.text, width - 18), 10, y + 2, DIM_COLOR, false);
                y += row.height;
                continue;
            }
            int x = row.type == RowType.QUEST ? 5 : 11;
            int textX = row.type == RowType.QUEST ? 9 : 16;
            if (row.icon != null && !row.icon.isEmpty()) {
                // Render FTB's actual item/quest icon, including custom and lazy icons.
                row.icon.draw(gui, x, y, 12, 12);
                textX = row.type == RowType.QUEST ? 20 : 26;
            }
            int color = row.locked ? LOCKED_COLOR : row.type == RowType.QUEST ? TEXT_COLOR : DIM_COLOR;
            int progressColor = row.locked ? LOCKED_COLOR : PROGRESS_COLOR;
            String progress = row.progress;
            int progressWidth = font.width(progress);
            int maxNameWidth = width - textX - progressWidth - 12;
            if (maxNameWidth > 6) gui.drawString(font, fit(font, row.text, maxNameWidth), textX, y + 2, color, false);
            gui.drawString(font, progress, width - 5 - progressWidth, y + 2, progressColor, false);
            y += row.height;
        }
        gui.pose().popPose();
    }

    private static String fit(Font font, String text, int available) {
        if (available <= 0) return "";
        if (font.width(text) <= available) return text;
        return font.plainSubstrByWidth(text, Math.max(0, available - font.width("…"))) + "…";
    }

    private static List<Quest> getQuests(ClientQuestFile file, TeamData data, Minecraft mc) {
        if (ClientTracker.isChainTracking()) {
            // Keep all unfinished quests reachable from the selected root instead
            // of reducing the entire chain to the first actionable quest.
            // Ready quests are first; visible locked successors remain in the queue.
            List<Quest> queue = new ArrayList<>();
            for (Quest quest : ClientTracker.chainQueue()) {
                if (quest.isVisible(data)) queue.add(quest);
            }
            queue.sort(Comparator.comparing((Quest q) -> !data.canStartTasks(q, false)));
            return queue;
        }
        List<Quest> result = new ArrayList<>();
        LongSet pinned = data.getPinnedQuestIds(mc.player);
        if (pinned == null || pinned.isEmpty()) return result;
        if (pinned.contains(TeamData.AUTO_PIN_ID)) {
            boolean wholeBook = FTBQuestsClientConfig.AUTO_PIN_FOLLOWS.get() == AutoPinTarget.QUEST_BOOK;
            file.forAllQuests(quest -> {
                if (!data.isCompleted(quest)
                        && quest.isVisible(data)
                        && data.canStartTasks(quest, !FTBQuestsClientConfig.PINNED_EXCLUDE_FLEXIBLE.get())
                        && (wholeBook || file.isChapterSelected(quest.getChapter()))) result.add(quest);
            });
        } else {
            for (long id : pinned) {
                Quest q = file.getQuest(id);
                if (q != null) result.add(q);
            }
        }
        result.sort(Comparator.comparingLong((Quest q) -> q.getChapter().getId())
                .thenComparingDouble(Quest::getY)
                .thenComparingDouble(Quest::getX)
                .thenComparingLong(Quest::getId));
        return result;
    }

    private enum RowType { QUEST, TASK, MORE, SPACING }

    private record Row(RowType type, String text, String progress, Icon icon, int height, boolean locked) {
        static Row quest(String name, String progress, Icon icon, boolean locked) {
            return new Row(RowType.QUEST, name, progress, icon, QUEST_ROW_HEIGHT, locked);
        }
        static Row task(String name, String progress, Icon icon, boolean locked) {
            return new Row(RowType.TASK, name, progress, icon, TASK_ROW_HEIGHT, locked);
        }
        static Row more(String text) { return new Row(RowType.MORE, text, "", null, 12, false); }
        static Row spacing(int height) { return new Row(RowType.SPACING, "", "", null, height, false); }
    }
}
