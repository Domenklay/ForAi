package com.domenklay.questchain;

import dev.ftb.mods.ftbquests.client.AutoPinTarget;
import dev.ftb.mods.ftbquests.client.ClientQuestFile;
import dev.ftb.mods.ftbquests.client.FTBQuestsClientConfig;
import dev.ftb.mods.ftbquests.client.PinnedTrackerVisibility;
import dev.ftb.mods.ftbquests.quest.Quest;
import dev.ftb.mods.ftbquests.quest.TeamData;
import dev.ftb.mods.ftbquests.quest.task.ItemTask;
import dev.ftb.mods.ftbquests.quest.task.Task;
import it.unimi.dsi.fastutil.longs.LongSet;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Replaces the *native* FTB pinned renderer, keeping its position, scale and visibility settings. */
public final class PinnedOverlayRenderer {
    private static final int WIDTH = 205;
    private static final int MAX_QUESTS = 5;
    private static final int MAX_TASK_ROWS = 10;
    private static final int MAX_TASKS_PER_QUEST = 5;
    private static final int HEADER_HEIGHT = 16;
    private static final int QUEST_ROW_HEIGHT = 12;
    private static final int TASK_ROW_HEIGHT = 14;
    private static final int TEXT_COLOR = 0xFFE7E7E7;
    private static final int PROGRESS_COLOR = 0xFF6FCFAF;
    private static final int DIM_COLOR = 0xFFB4B4B4;

    // Large quest books can contain thousands of quests. Avoid traversing them each render frame.
    private static ClientQuestFile cachedFile;
    private static long lastScanTick = Long.MIN_VALUE;
    private static boolean cachedChainMode;
    private static List<Quest> cachedQuests = List.of();

    private PinnedOverlayRenderer() {}

    public static void render(Minecraft mc, GuiGraphics gui) {
        if (mc.player == null || mc.options.hideGui || !ClientQuestFile.exists()) return;
        if (!ClientTracker.isHudVisible() || FTBQuestsClientConfig.PINNED_VISIBILITY.get() == PinnedTrackerVisibility.HIDDEN) return;

        ClientQuestFile file = ClientQuestFile.getInstance();
        TeamData data = file.selfTeamData;
        if (data == null) return;

        boolean chainMode = ClientTracker.isChainTracking();
        long gameTick = mc.level == null ? 0 : mc.level.getGameTime();
        if (file != cachedFile || cachedChainMode != chainMode || gameTick < lastScanTick || gameTick - lastScanTick >= 10L) {
            cachedQuests = getQuests(file, data, mc);
            cachedFile = file;
            cachedChainMode = chainMode;
            lastScanTick = gameTick;
        }
        List<Quest> pinnedQuests = cachedQuests;
        if (pinnedQuests.isEmpty() && !chainMode) return;

        List<Row> rows = new ArrayList<>();
        int shownQuests = 0;
        int shownTasks = 0;
        for (Quest quest : pinnedQuests) {
            if (shownQuests >= MAX_QUESTS || shownTasks >= MAX_TASK_ROWS) break;
            if (shownQuests > 0) rows.add(Row.spacing(3));
            rows.add(Row.quest(quest.getTitle().getString(), data.getRelativeProgress(quest) + "%"));
            shownQuests++;

            if (FTBQuestsClientConfig.PINNED_VISIBILITY.get() == PinnedTrackerVisibility.ALL) {
                int thisQuestTasks = 0;
                for (Task task : quest.getTasks()) {
                    if (shownTasks >= MAX_TASK_ROWS || thisQuestTasks >= MAX_TASKS_PER_QUEST) break;
                    if (data.isCompleted(task)) continue;
                    ItemStack icon = ItemStack.EMPTY;
                    if (task instanceof ItemTask itemTask) {
                        icon = itemTask.getItemStack();
                        if (icon.isEmpty() && !itemTask.getValidDisplayItems().isEmpty()) {
                            icon = itemTask.getValidDisplayItems().getFirst();
                        }
                    }
                    rows.add(Row.task(task.getMutableTitle().getString(),
                            task.formatProgress(data, data.getProgress(task)) + "/" + task.formatMaxProgress(), icon));
                    thisQuestTasks++;
                    shownTasks++;
                }
                long left = quest.getTasks().stream().filter(t -> !data.isCompleted(t)).count() - thisQuestTasks;
                if (left > 0) rows.add(Row.more("+" + left + " …"));
            }
        }
        if (chainMode && pinnedQuests.isEmpty()) {
            rows.add(Row.more(Component.translatable("hud.ftbchaintracker.waiting").getString()));
        } else if (pinnedQuests.size() > shownQuests) {
            rows.add(Row.more("+" + (pinnedQuests.size() - shownQuests) + " …"));
        }

        int height = HEADER_HEIGHT + 5;
        for (Row row : rows) height += row.height;
        int width = Math.min(WIDTH, Math.max(100, gui.guiWidth() - 12));
        double s = FTBQuestsClientConfig.PINNED_QUESTS_SCALE.get();
        float scale = (float) s;
        int insetX = FTBQuestsClientConfig.PINNED_QUESTS_INSET_X.get();
        int insetY = FTBQuestsClientConfig.PINNED_QUESTS_INSET_Y.get();
        var pos = FTBQuestsClientConfig.PINNED_QUESTS_POS.get().getPanelPos(
                gui.guiWidth(), gui.guiHeight(),
                (int) Math.ceil(width * s), (int) Math.ceil(height * s), insetX, insetY);
        Font font = mc.font;

        gui.pose().pushPose();
        gui.pose().translate(pos.x(), pos.y(), 0);
        gui.pose().scale(scale, scale, 1);
        // Original FTB Quests aesthetic: dark translucent panel and a subtle grey title bar.
        gui.fill(0, 0, width, height, 0xA9000000);
        gui.fill(1, 1, width - 1, HEADER_HEIGHT, 0x535A5A5A);
        gui.fill(0, HEADER_HEIGHT, width, HEADER_HEIGHT + 1, 0xDD000000);
        Component header = Component.translatable("ftbquests.pinned");
        String title = header.getString();
        if (chainMode) title += " · " + Component.translatable("hud.ftbchaintracker.chain").getString();
        title = fit(font, title, width - 12);
        gui.drawString(font, title, (width - font.width(title)) / 2, 4, 0xFFFFFF7A, false);

        int y = HEADER_HEIGHT + 3;
        for (Row row : rows) {
            if (row.height == 3) { y += 3; continue; }
            if (row.type == RowType.QUEST) {
                String pct = row.progress;
                int pctWidth = font.width(pct);
                gui.drawString(font, fit(font, row.text, width - 15 - pctWidth), 5, y + 1, TEXT_COLOR, true);
                gui.drawString(font, pct, width - 5 - pctWidth, y + 1, PROGRESS_COLOR, false);
            } else if (row.type == RowType.TASK) {
                int textX = row.icon.isEmpty() ? 11 : 24;
                if (!row.icon.isEmpty()) {
                    // Native item sprite, scaled to 12x12 for the pinned list.
                    gui.pose().pushPose();
                    gui.pose().translate(6, y, 0);
                    gui.pose().scale(0.75f, 0.75f, 1);
                    gui.renderItem(row.icon, 0, 0);
                    gui.pose().popPose();
                }
                int valueWidth = font.width(row.progress);
                int maxNameWidth = width - textX - valueWidth - 10;
                if (maxNameWidth > 6) {
                    gui.drawString(font, fit(font, row.text, maxNameWidth), textX, y + 2, DIM_COLOR, false);
                }
                gui.drawString(font, row.progress, width - 5 - valueWidth, y + 2, PROGRESS_COLOR, false);
            } else {
                gui.drawString(font, fit(font, row.text, width - 15), 11, y + 2, DIM_COLOR, false);
            }
            y += row.height;
        }
        gui.pose().popPose();
    }

    private static String fit(Font font, String text, int available) {
        if (available <= 0) return "";
        if (font.width(text) <= available) return text;
        return font.plainSubstrByWidth(text, Math.max(0, available - font.width("…"))) + "…";
    }

    private static List<Quest> getQuests(ClientQuestFile file, TeamData data, Minecraft mc) {
        if (ClientTracker.isChainTracking()) {
            return ClientTracker.currentChainQuest().map(List::of).orElseGet(List::of);
        }
        List<Quest> result = new ArrayList<>();
        LongSet pinned = data.getPinnedQuestIds(mc.player);
        if (pinned == null || pinned.isEmpty()) return result;
        if (pinned.contains(TeamData.AUTO_PIN_ID)) {
            boolean wholeBook = FTBQuestsClientConfig.AUTO_PIN_FOLLOWS.get() == AutoPinTarget.QUEST_BOOK;
            file.forAllQuests(quest -> {
                if (!data.isCompleted(quest)
                        && quest.isVisible(data)
                        && data.canStartTasks(quest, !FTBQuestsClientConfig.PINNED_EXCLUDE_FLEXIBLE.get())
                        && (wholeBook || file.isChapterSelected(quest.getChapter()))) result.add(quest);
            });
        } else {
            for (long id : pinned) {
                Quest q = file.getQuest(id);
                if (q != null) result.add(q);
            }
        }
        result.sort(Comparator.comparingLong((Quest q) -> q.getChapter().getId())
                .thenComparingDouble(Quest::getY)
                .thenComparingDouble(Quest::getX)
                .thenComparingLong(Quest::getId));
        return result;
    }

    private enum RowType {QUEST, TASK, MORE}

    private record Row(RowType type, String text, String progress, ItemStack icon, int height) {
        static Row quest(String name, String progress) { return new Row(RowType.QUEST, name, progress, ItemStack.EMPTY, QUEST_ROW_HEIGHT); }
        static Row task(String name, String progress, ItemStack icon) { return new Row(RowType.TASK, name, progress, icon, TASK_ROW_HEIGHT); }
        static Row more(String message) { return new Row(RowType.MORE, message, "", ItemStack.EMPTY, 12); }
        static Row spacing(int height) { return new Row(RowType.MORE, "", "", ItemStack.EMPTY, height); }
    }
}
