package com.domenklay.questchain;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.ToLongFunction;

/** Pure Java dependency graph walk, independent from Minecraft / FTB. */
public final class ChainPlanner {
    private ChainPlanner() {}

    /** Pending quests are ordered by graph traversal, including visible but not yet unlocked ones. */
    public record Result<T>(List<T> actionable, List<T> pending, int total, int incomplete, boolean capped) {}

    /**
     * Breadth-first traversal from a chosen quest. A quest is actionable only if it is
     * unfinished, visible, and actually startable according to FTB progression rules.
     * Complete quests remain traversable, so the next quest appears automatically.
     */
    public static <T> Result<T> inspect(
            T root,
            Function<T, ? extends Collection<T>> children,
            Predicate<T> completed,
            Predicate<T> actionable,
            ToLongFunction<T> id,
            Comparator<T> order,
            int maxNodes) {
        if (root == null || maxNodes <= 0) return new Result<>(List.of(), List.of(), 0, 0, false);

        ArrayDeque<T> queue = new ArrayDeque<>();
        Set<Long> visited = new HashSet<>();
        List<T> active = new ArrayList<>();
        List<T> pending = new ArrayList<>();
        int total = 0;
        int remaining = 0;

        queue.add(root);
        visited.add(id.applyAsLong(root));
        while (!queue.isEmpty() && total < maxNodes) {
            T current = queue.removeFirst();
            total++;
            if (!completed.test(current)) {
                remaining++;
                pending.add(current);
                if (actionable.test(current)) active.add(current);
            }
            Collection<T> neighbours = children.apply(current);
            if (neighbours == null || neighbours.isEmpty()) continue;
            List<T> ordered = new ArrayList<>(neighbours);
            ordered.sort(order);
            for (T next : ordered) {
                if (next != null && visited.add(id.applyAsLong(next))) queue.addLast(next);
            }
        }
        return new Result<>(List.copyOf(active), List.copyOf(pending), total, remaining, !queue.isEmpty());
    }
}
