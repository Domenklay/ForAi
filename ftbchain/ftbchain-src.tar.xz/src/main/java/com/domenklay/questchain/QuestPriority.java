package com.domenklay.questchain;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Pure Java priority and size-limiting rules for the quest objective HUD. */
public final class QuestPriority {
    private QuestPriority() {}

    /**
     * completedObjectives: objectives already fully satisfied within a still-unfinished quest.
     * progressPercent: progress of the parent quest (0..100).
     * questOrder: order from the original dependency walk, nearest first.
     */
    public record Entry<T>(T quest, int completedObjectives, int progressPercent, int questOrder) {}

    public static <T> List<Entry<T>> ordered(List<Entry<T>> entries) {
        List<Entry<T>> copy = new ArrayList<>(entries);
        copy.sort(Comparator
                .comparingInt((Entry<T> e) -> e.completedObjectives() > 0 ? 0 : 1)
                .thenComparing(Comparator.comparingInt((Entry<T> e) -> e.completedObjectives()).reversed())
                .thenComparing(Comparator.comparingInt((Entry<T> e) -> e.progressPercent()).reversed())
                .thenComparingInt(Entry::questOrder));
        return List.copyOf(copy);
    }

    /** Maximum actual item/task lines, not maximum quests. */
    public static int visibleRows(int available, int limit) {
        return Math.max(0, Math.min(available, limit));
    }
}
