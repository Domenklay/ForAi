package com.domenklay.questchain;

import com.mojang.blaze3d.platform.InputConstants;
import dev.ftb.mods.ftbquests.client.ClientQuestFile;
import dev.ftb.mods.ftbquests.client.gui.quests.QuestScreen;
import dev.ftb.mods.ftbquests.quest.Quest;
import dev.ftb.mods.ftbquests.quest.QuestObject;
import dev.ftb.mods.ftbquests.quest.TeamData;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.client.event.ScreenEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.tick.ClientTickEvent;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

/** Client-side progression tracker, based on quest dependencies synced by FTB Quests. */
public final class ClientTracker {
    private static final int MAX_NODES = 1200;
    private static final int UPDATE_INTERVAL = 20;
    private static final int BUTTON_W = 149, BUTTON_H = 18, BUTTON_Y = 32;
    private static final KeyMapping TOGGLE_HUD = new KeyMapping(
            "key.ftbchaintracker.toggle", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_H,
            "key.categories.ftbchaintracker");

    private static TrackerStore store;
    private static String worldKey;
    private static Long rootId;
    private static ChainPlanner.Result<Quest> plan = new ChainPlanner.Result<>(List.of(), 0, 0, false);
    private static boolean hudEnabled = true;
    private static int ticks = 0;

    private ClientTracker() {}

    public static void init(IEventBus modBus) {
        store = new TrackerStore();
        modBus.addListener(ClientTracker::registerKeys);
        NeoForge.EVENT_BUS.addListener(ClientTracker::tick);
        NeoForge.EVENT_BUS.addListener(ClientTracker::hud);
        NeoForge.EVENT_BUS.addListener(ClientTracker::questScreenRender);
        NeoForge.EVENT_BUS.addListener(ClientTracker::questScreenClick);
        NeoForge.EVENT_BUS.addListener(ClientTracker::questScreenKey);
    }

    private static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(TOGGLE_HUD);
    }

    private static void tick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) {
            worldKey = null;
            rootId = null;
            plan = new ChainPlanner.Result<>(List.of(), 0, 0, false);
            return;
        }
        String newKey = getWorldKey(mc);
        if (!Objects.equals(newKey, worldKey)) {
            worldKey = newKey;
            rootId = store.get(worldKey);
            ticks = UPDATE_INTERVAL;
        }
        while (TOGGLE_HUD.consumeClick()) {
            hudEnabled = !hudEnabled;
            actionbar(hudEnabled ? "message.ftbchaintracker.hud_on" : "message.ftbchaintracker.hud_off");
        }
        if (++ticks >= UPDATE_INTERVAL) {
            ticks = 0;
            updatePlan();
        }
    }

    private static String getWorldKey(Minecraft mc) {
        if (mc.getSingleplayerServer() != null) {
            return "singleplayer:" + mc.getSingleplayerServer().getWorldData().getLevelName();
        }
        if (mc.getCurrentServer() != null) {
            return "multiplayer:" + mc.getCurrentServer().ip;
        }
        return "unknown:" + (mc.level == null ? "none" : mc.level.dimension().location());
    }

    private static void updatePlan() {
        if (rootId == null || !ClientQuestFile.exists()) {
            plan = new ChainPlanner.Result<>(List.of(), 0, 0, false);
            return;
        }
        ClientQuestFile file = ClientQuestFile.getInstance();
        TeamData team = file.selfTeamData;
        Quest root = file.getQuest(rootId);
        if (root == null || team == null) {
            plan = new ChainPlanner.Result<>(List.of(), 0, 0, false);
            return;
        }
        // A dependent may be in a different chapter. Sort by visual quest position.
        plan = ChainPlanner.inspect(root,
                q -> {
                    List<Quest> followups = new ArrayList<>();
                    for (QuestObject dependant : q.getDependants()) {
                        if (dependant instanceof Quest child) followups.add(child);
                    }
                    return followups;
                },
                team::isCompleted,
                q -> q.isVisible(team) && team.canStartTasks(q, false),
                Quest::getId,
                Comparator.comparingLong((Quest q) -> q.getChapter().getId())
                        .thenComparingDouble(Quest::getY)
                        .thenComparingDouble(Quest::getX)
                        .thenComparingLong(Quest::getId),
                MAX_NODES);

        if (plan.incomplete() == 0 && !plan.capped()) {
            // Completed a full selected chain; do not leave a dead tracker panel.
            stop();
            actionbar("message.ftbchaintracker.complete");
        }
    }

    private static void choose(Quest quest) {
        if (worldKey == null || quest == null) return;
        if (rootId != null && rootId == quest.getId()) {
            stop();
            actionbar("message.ftbchaintracker.stopped");
        } else {
            rootId = quest.getId();
            store.put(worldKey, rootId);
            hudEnabled = true;
            ticks = UPDATE_INTERVAL;
            updatePlan();
            actionbar("message.ftbchaintracker.started");
        }
    }

    private static void stop() {
        rootId = null;
        plan = new ChainPlanner.Result<>(List.of(), 0, 0, false);
        if (worldKey != null) store.put(worldKey, null);
    }

    private static void actionbar(String key) {
        if (Minecraft.getInstance().player != null) {
            Minecraft.getInstance().player.displayClientMessage(Component.translatable(key), true);
        }
    }

    private static Quest viewedQuest(QuestScreen screen) {
        return screen.getViewedQuest();
    }

    private static int buttonX(GuiGraphics graphics) {
        return Math.max(4, graphics.guiWidth() - BUTTON_W - 35);
    }

    /** Visible action in the actual quest book instead of an inaccessible config-only toggle. */
    private static void questScreenRender(ScreenEvent.Render.Post event) {
        if (!(event.getScreen() instanceof QuestScreen screen)) return;
        Quest quest = viewedQuest(screen);
        if (quest == null) return;
        GuiGraphics g = event.getGuiGraphics();
        int x = buttonX(g), y = BUTTON_Y;
        boolean trackingThis = rootId != null && rootId == quest.getId();
        boolean hover = event.getMouseX() >= x && event.getMouseX() < x + BUTTON_W
                && event.getMouseY() >= y && event.getMouseY() < y + BUTTON_H;
        g.fill(x, y, x + BUTTON_W, y + BUTTON_H, hover ? 0xE7355648 : 0xE7212929);
        g.fill(x, y, x + 2, y + BUTTON_H, trackingThis ? 0xFFFFB65D : 0xFF63D69A);
        Component txt = Component.translatable(trackingThis ? "gui.ftbchaintracker.stop" : "gui.ftbchaintracker.start");
        g.drawString(Minecraft.getInstance().font, txt, x + 7, y + 5, 0xFFE8F1EA, false);
    }

    private static void questScreenClick(ScreenEvent.MouseButtonPressed.Pre event) {
        if (event.getButton() != GLFW.GLFW_MOUSE_BUTTON_LEFT || !(event.getScreen() instanceof QuestScreen screen)) return;
        Quest quest = viewedQuest(screen);
        if (quest == null) return;
        int x = Math.max(4, screen.width - BUTTON_W - 35);
        if (event.getMouseX() >= x && event.getMouseX() < x + BUTTON_W
                && event.getMouseY() >= BUTTON_Y && event.getMouseY() < BUTTON_Y + BUTTON_H) {
            choose(quest);
            event.setCanceled(true);
        }
    }

    /** Keyboard fallback while viewing a quest; only intercept G with no modifiers. */
    private static void questScreenKey(ScreenEvent.KeyPressed.Pre event) {
        if (event.getKeyCode() == GLFW.GLFW_KEY_G && event.getModifiers() == 0
                && event.getScreen() instanceof QuestScreen screen) {
            Quest quest = viewedQuest(screen);
            if (quest != null) {
                choose(quest);
                event.setCanceled(true);
            }
        }
    }

    private static void hud(RenderGuiEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.screen != null || mc.options.hideGui) return;
        if (!hudEnabled || rootId == null || !ClientQuestFile.exists()) return;
        HudRenderer.draw(event.getGuiGraphics(), mc, plan, ClientQuestFile.getInstance().selfTeamData);
    }
}
