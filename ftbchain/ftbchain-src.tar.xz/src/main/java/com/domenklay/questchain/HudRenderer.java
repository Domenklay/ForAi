package com.domenklay.questchain;

import dev.ftb.mods.ftbquests.quest.Quest;
import dev.ftb.mods.ftbquests.quest.TeamData;
import dev.ftb.mods.ftbquests.quest.task.ItemTask;
import dev.ftb.mods.ftbquests.quest.task.Task;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

/** Compact right-hand HUD with genuine item model icons for tracked item tasks. */
final class HudRenderer {
    private static final int PANEL_W = 232;
    private static final int MAX_QUESTS = 1;
    private static final int MAX_TASKS = 5;
    private static final int ROW_H = 19;

    private HudRenderer() {}

    static void draw(GuiGraphics g, Minecraft mc, ChainPlanner.Result<Quest> plan, TeamData team) {
        if (team == null || plan.total() == 0) return;
        Font font = mc.font;
        List<Quest> active = plan.actionable();
        int questsShown = Math.min(MAX_QUESTS, active.size());
        int height = 25;
        List<List<Task>> tasks = new ArrayList<>();
        for (int i = 0; i < questsShown; i++) {
            List<Task> todo = active.get(i).getTasks().stream().filter(t -> !team.isCompleted(t)).toList();
            tasks.add(todo);
            height += 18 + Math.min(todo.size(), MAX_TASKS) * ROW_H + (todo.size() > MAX_TASKS ? 12 : 0) + 4;
        }
        if (questsShown == 0) height += 19;
        if (active.size() > questsShown) height += 12;
        height += 5;

        int x = Math.max(4, g.guiWidth() - PANEL_W - 8);
        int y = 35;
        if (y + height > g.guiHeight() - 16) y = Math.max(10, g.guiHeight() - height - 12);
        int w = Math.min(PANEL_W, g.guiWidth() - x - 4);
        if (w < 110) return;

        g.fill(x, y, x + w, y + height, 0xC8181C1F);
        g.fill(x, y, x + 2, y + height, 0xFF64D6A3);
        g.fill(x, y, x + w, y + 20, 0xCC252D30);
        g.drawString(font, Component.translatable("hud.ftbchaintracker.header"), x + 8, y + 6, 0xFF9DECC0, false);
        String counter = Integer.toString(Math.max(0, plan.total() - plan.incomplete())) + "/" + plan.total();
        g.drawString(font, counter, x + w - 8 - font.width(counter), y + 6, 0xFFD0D6D4, false);
        int cursorY = y + 24;

        if (questsShown == 0) {
            String waiting = Component.translatable("hud.ftbchaintracker.waiting").getString();
            g.drawString(font, clip(font, waiting, w - 18), x + 9, cursorY + 4, 0xFFFFCF83, false);
            return;
        }
        for (int i = 0; i < questsShown; i++) {
            Quest quest = active.get(i);
            String label = quest.getTitle().getString();
            g.drawString(font, clip(font, label, w - 54), x + 8, cursorY, 0xFFFFFFFF, false);
            String percent = team.getRelativeProgress(quest) + "%";
            g.drawString(font, percent, x + w - 8 - font.width(percent), cursorY, 0xFF9DDBC3, false);
            cursorY += 18;

            List<Task> todo = tasks.get(i);
            for (int j = 0; j < Math.min(todo.size(), MAX_TASKS); j++) {
                Task task = todo.get(j);
                ItemStack icon = ItemStack.EMPTY;
                String name = task.getMutableTitle().getString();
                if (task instanceof ItemTask itemTask) {
                    icon = itemTask.getItemStack();
                    if (!icon.isEmpty()) name = icon.getHoverName().getString();
                } else {
                    icon = new ItemStack(Items.PAPER);
                }
                if (!icon.isEmpty()) g.renderItem(icon, x + 7, cursorY - 3);
                g.drawString(font, clip(font, name, w - 99), x + 27, cursorY + 1, 0xFFE0E3E5, false);
                String count = compact(team.getProgress(task)) + "/" + compact(task.getMaxProgress());
                g.drawString(font, count, x + w - 7 - font.width(count), cursorY + 1, 0xFFA5D9B0, false);
                cursorY += ROW_H;
            }
            if (todo.size() > MAX_TASKS) {
                g.drawString(font, "+" + (todo.size() - MAX_TASKS) + " ...", x + 29, cursorY, 0xFFBCBFC0, false);
                cursorY += 12;
            }
            cursorY += 4;
        }
        if (active.size() > questsShown) {
            String suffix = Component.translatable("hud.ftbchaintracker.more", active.size() - questsShown).getString();
            g.drawString(font, clip(font, suffix, w - 16), x + 8, cursorY, 0xFFB6BDB9, false);
        }
    }

    private static String clip(Font font, String text, int width) {
        return font.width(text) <= width ? text : font.plainSubstrByWidth(text, Math.max(0, width - font.width("…"))) + "…";
    }

    private static String compact(long v) {
        if (v >= 1_000_000) return (v / 1_000_000) + "M";
        if (v >= 10_000) return (v / 1_000) + "k";
        return Long.toString(v);
    }
}
