import com.domenklay.questchain.ChainPlanner;
import java.util.*;

public final class ChainPlannerTest {
    private static final class Q {
        final long id;
        boolean done;
        boolean ready;
        final List<Q> children = new ArrayList<>();
        Q(long id, boolean done, boolean ready) { this.id=id; this.done=done; this.ready=ready; }
        Q next(Q q) { children.add(q); return this; }
    }
    private static ChainPlanner.Result<Q> run(Q q) {
        return ChainPlanner.inspect(q, n -> n.children, n -> n.done,
                n -> n.ready, n -> n.id, Comparator.comparingLong(n -> n.id), 128);
    }
    private static void equal(Object a, Object b) {if (!Objects.equals(a,b)) throw new AssertionError(a + " != " + b);}
    public static void main(String[] args) {
        Q a = new Q(1,false,true), b = new Q(2,false,false), c = new Q(3,false,false);
        a.next(b); b.next(c);
        equal(run(a).actionable().stream().map(n -> n.id).toList(), List.of(1L));
        a.done = true; b.ready = true;
        equal(run(a).actionable().stream().map(n -> n.id).toList(), List.of(2L));
        b.done = true; c.ready = true;
        equal(run(a).actionable().stream().map(n -> n.id).toList(), List.of(3L));
        c.done = true;
        equal(run(a).incomplete(), 0);
        // Branching, ordering, cycle detection, and a quest not yet startable.
        Q d = new Q(4,true,true), e = new Q(9,false,true), f = new Q(7,false,true);
        d.next(e).next(f); e.next(d);
        equal(run(d).actionable().stream().map(n -> n.id).toList(), List.of(7L,9L));
        equal(run(d).total(), 3);
        Q blocked = new Q(11,false,false); e.next(blocked);
        equal(run(d).incomplete(), 3);
        equal(run(d).actionable().size(), 2);
        equal(ChainPlanner.inspect(d, n -> n.children, n -> n.done,
                n -> n.ready, n -> n.id, Comparator.comparingLong(n -> n.id), 2).capped(), true);
        System.out.println("PASS: 8 chain progression / branching / cycle / locked quest checks");
    }
}
