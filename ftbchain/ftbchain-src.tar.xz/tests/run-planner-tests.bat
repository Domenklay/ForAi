@echo off
cd /d "%~dp0.."
if not exist build\planner-test mkdir build\planner-test
javac -encoding UTF-8 -d build\planner-test src\main\java\com\domenklay\questchain\ChainPlanner.java src\main\java\com\domenklay\questchain\QuestPriority.java tests\ChainPlannerTest.java tests\QuestPriorityTest.java
if errorlevel 1 exit /b 1
java -cp build\planner-test ChainPlannerTest

if errorlevel 1 exit /b 1
java -cp build\planner-test QuestPriorityTest
