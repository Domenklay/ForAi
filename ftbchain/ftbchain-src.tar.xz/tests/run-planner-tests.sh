#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build/planner-test
javac -encoding UTF-8 -d build/planner-test \
  src/main/java/com/domenklay/questchain/ChainPlanner.java \
  tests/ChainPlannerTest.java
java -cp build/planner-test ChainPlannerTest
