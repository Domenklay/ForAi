import com.domenklay.questchain.QuestPriority;
import java.util.List;

public class QuestPriorityTest {
    public static void main(String[] args) {
        var entries = List.of(
                new QuestPriority.Entry<>("untouched but nearby", 0, 0, 0),
                new QuestPriority.Entry<>("iron after coal finished", 1, 50, 4),
                new QuestPriority.Entry<>("unlocked partial item", 0, 30, 1),
                new QuestPriority.Entry<>("more objectives completed", 2, 40, 7),
                new QuestPriority.Entry<>("untouched later", 0, 0, 9));
        List<String> sorted = QuestPriority.ordered(entries).stream().map(QuestPriority.Entry::quest).toList();
        require(sorted.equals(List.of("more objectives completed", "iron after coal finished",
                "unlocked partial item", "untouched but nearby", "untouched later")), "progress priority");
        require(QuestPriority.visibleRows(131, 20) == 20, "limit to 20 objectives");
        require(QuestPriority.visibleRows(6, 20) == 6, "do not pad small lists");
        require(QuestPriority.visibleRows(131, 0) == 0, "height limit");
        System.out.println("QuestPriority tests passed");
    }
    private static void require(boolean yes, String msg) {
        if (!yes) throw new AssertionError(msg);
    }
}
